package Inmobilaria.GyL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GyLApplication {

	public static void main(String[] args) {
		SpringApplication.run(GyLApplication.class, args);
	}

}
